This plugin allows you to display a simple calculator on your website using jQuery.

The user name is 'user' and the password is 'ps@1234'.

Licence
-------
[GPL v3](http://www.gnu.org/licenses/gpl.html)